<?php

include_once __DIR__ . '/inc/functions/theme_setup.php';
include_once __DIR__ . '/inc/functions/acf.php';
